package com.example.testando_fragment

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.fragmentContainer, NoteListFragment())
                .commit()
        }
    }

    fun showNoteDetail(note: String) {

        if(note == "Sair"){

            finish()
            System.exit(0)

        }

        else if(note == "Começar"){
            val intent = Intent(this, Quest_1::class.java)
            //intent.putExtra(NoteDetailActivity.EXTRA_NOTE, note)
            startActivity(intent)
        }

        else{

            val intent = Intent(this, DiarioActivity::class.java)
            startActivity(intent)

        }
    }
}
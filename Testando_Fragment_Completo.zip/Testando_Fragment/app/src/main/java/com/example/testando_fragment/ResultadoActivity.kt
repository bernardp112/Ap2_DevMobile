package com.example.testando_fragment

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultadoActivity : AppCompatActivity(){

    companion object {
        val total = "total"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        val total = intent.getStringExtra(total)
        val totalTitleTextView = findViewById<TextView>(R.id.resultadoView)
        if (total == "0"){

            totalTitleTextView.text = "\"A vida é um presente precioso. Aproveite cada dia, cada hora, cada minuto. Não perca tempo se preocupando com o que não importa, e sim valorize as coisas que realmente fazem a diferença.\" - Jack Canfield"

        }
        else if (total == "1" || total == "2"){

            totalTitleTextView.text = "\"Pedir ajuda não é sinal de fraqueza mas sim de humildade e sabedoria.\" - Daniel Godri Junior"

        }
        else if (total == "3"){

            totalTitleTextView.text = "\"A vida pode parecer pesada, mas lembre-se de que você é mais forte do que imagina. Procure ajuda e permita que outros sejam seus pilares de apoio.\""

        }

        val btAjuda = findViewById<ImageButton>(R.id.helpButton)
        btAjuda.setOnClickListener {

            val intent = Intent(this@ResultadoActivity, AjudaActivity::class.java)
            startActivity(intent)

        }

    }

}
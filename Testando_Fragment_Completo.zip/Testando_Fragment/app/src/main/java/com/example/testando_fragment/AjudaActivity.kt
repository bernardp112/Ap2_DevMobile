package com.example.testando_fragment

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class AjudaActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ajuda)
        val buttonLigar = findViewById<Button>(R.id.ligarButton)
        buttonLigar.setOnClickListener(){

            val telefone = "188"
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$telefone"))
            startActivity(intent)

        }
    }

}
package com.example.testando_fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.fragment.app.Fragment

class NoteListFragment : Fragment() {
    private lateinit var listView: ListView
    private lateinit var noteListAdapter: ArrayAdapter<String>
    private lateinit var noteList: ArrayList<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_note_list, container, false)

        // Inicializar a lista de notas
        noteList = ArrayList()
        noteList.add("Começar")
        noteList.add("Desabafo")
        noteList.add("Sair")

        // Inicializar o adapter da lista de notas
        noteListAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, noteList)

        // Configurar a ListView
        listView = view.findViewById(R.id.noteListView)
        listView.adapter = noteListAdapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedNote = noteList[position]
            (activity as MainActivity).showNoteDetail(selectedNote)
        }

        return view
    }
}
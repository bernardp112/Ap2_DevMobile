package com.example.testando_fragment

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Quest_2 : AppCompatActivity() {

    companion object {
        var total = "total"
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_detail)
        var total = intent.getStringExtra(Quest_2.total)
        val questao1TitleTextView = findViewById<TextView>(R.id.pergunta)
        questao1TitleTextView.text = "Você tem experimentado uma falta de interesse ou prazer nas atividades que antes lhe davam prazer?\n"
        val btSim = findViewById<Button>(R.id.buttonSim)
        btSim.setOnClickListener {

            if(total == "0"){
                total = "1"
            }
            else if(total == "1"){
                total = "2"
            }
            val intent = Intent(this@Quest_2, Quest_3::class.java)
            intent.putExtra(Quest_3.total, total)
            startActivity(intent)

        }

        val btNao = findViewById<Button>(R.id.buttonNao)
        btNao.setOnClickListener {

            val intent = Intent(this@Quest_2, Quest_3::class.java)
            intent.putExtra(Quest_3.total, total)
            startActivity(intent)

        }
    }

}
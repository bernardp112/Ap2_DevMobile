package com.example.testando_fragment

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Quest_1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_detail)
        val questao1TitleTextView = findViewById<TextView>(R.id.pergunta)
        questao1TitleTextView.text = "Você sente uma sensação constante de tristeza, desesperança ou vazio?"
        val btSim = findViewById<Button>(R.id.buttonSim)
        btSim.setOnClickListener {

            var total = "1"
            val intent = Intent(this@Quest_1, Quest_2::class.java)
            intent.putExtra(Quest_2.total, total)
            startActivity(intent)

        }
        val btNao = findViewById<Button>(R.id.buttonNao)
        btNao.setOnClickListener {

            var total = "0"
            val intent = Intent(this@Quest_1, Quest_2::class.java)
            intent.putExtra(Quest_2.total, total)
            startActivity(intent)

        }
    }
}